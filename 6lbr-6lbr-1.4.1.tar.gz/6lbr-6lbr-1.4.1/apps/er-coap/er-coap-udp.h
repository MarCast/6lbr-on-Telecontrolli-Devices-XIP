#ifndef _ER_COAP_UPD_H_
#define _ER_COAP_UPD_H_

typedef struct uip_udp_conn context_t;

#endif
