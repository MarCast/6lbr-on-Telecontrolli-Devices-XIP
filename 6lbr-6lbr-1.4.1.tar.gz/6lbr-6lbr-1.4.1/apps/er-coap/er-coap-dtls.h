#ifndef _ER_COAP_DTLS_H_
#define _ER_COAP_DTLS_H_

typedef struct dtls_context_t context_t;

#endif
